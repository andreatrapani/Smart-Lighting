#include "mbed.h"

Serial pc(USBTX, USBRX);
InterruptIn PIR1(D2);
InterruptIn PIR2(D3);
InterruptIn PIR3(D4);
InterruptIn PIR4(D5);
InterruptIn PIR5(D6);
DigitalOut myled1(D7);
DigitalOut myled2(D0);
DigitalOut myled3(D1);
DigitalOut myled4(D8);
DigitalOut myled5(D9);
int PIR_Detected = 0;
int PIR2_Detected = 0;
int PIR3_Detected = 0;
int PIR4_Detected = 0;
int PIR5_Detected = 0;

void irq_handler(void)
{
    PIR_Detected = 1;
}
void irq_handler2(void)
{
    PIR2_Detected = 1;
}
void irq_handler3(void)
{
    PIR3_Detected = 1;
}
void irq_handler4(void)
{
    PIR4_Detected = 1;
}
void irq_handler5(void)
{
    PIR5_Detected = 1;
}

int main()
{
    while(1){
        
    PIR1.rise(&irq_handler);
    PIR2.rise(&irq_handler2);
    PIR3.rise(&irq_handler3);
    PIR4.rise(&irq_handler4);
    PIR5.rise(&irq_handler5);
    
        if (PIR_Detected) {
            myled1 = 1;
            PIR_Detected = 0;
            wait(5);
            pc.printf("Movimento rilevato\n\r");
        }else{
        myled1 = 0;
        wait(0.2);
        pc.printf("Movimento non rilevato\n\r");
        }
        
        
        if (PIR2_Detected) {
            myled2 = 1;
            PIR2_Detected = 0;
            wait(5);
            pc.printf("Movimento 2 rilevato\n\r");
        }else{
        myled2 = 0;
        wait(0.2);
        pc.printf("Movimento 2 non rilevato\n\r");
        }
        
        
        if (PIR3_Detected) {
            myled3 = 1;
            PIR3_Detected = 0;
            wait(5);
            pc.printf("Movimento 3 rilevato\n\r");
        }else{
        myled3 = 0;
        wait(0.2);
        pc.printf("Movimento 3 non rilevato\n\r");
        }
        
        
        if (PIR4_Detected) {
            myled4 = 1;
            PIR4_Detected = 0;
            wait(5);
            pc.printf("Movimento 4 rilevato\n\r");
        }else{
        myled4 = 0;
        wait(0.2);
        pc.printf("Movimento 4 non rilevato\n\r");
        }
        
        
        if (PIR5_Detected) {
            myled5 = 1;
            PIR5_Detected = 0;
            wait(5);
            pc.printf("Movimento 5 rilevato\n\r");
        }else{
        myled5 = 0;
        wait(0.2);
        pc.printf("Movimento 5 non rilevato\n\r");
        }
    }
}

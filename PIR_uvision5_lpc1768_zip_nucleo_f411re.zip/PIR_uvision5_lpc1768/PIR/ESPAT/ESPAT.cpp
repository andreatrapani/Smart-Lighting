#include "ESPAT.h"
#include "mbed.h"
#include "string"

/*
Library for using an ESP8266 (e.g. ESP-01 board) with its AT command firmware as webserver
Version: 1.0.0
(C)2019 Elias Nestl
*/

ESPAT::ESPAT(PinName tx, PinName rx, int baud) : espSerial(tx, rx, baud) {
}

//Serial pc(USBTX, USBRX, 115200);

void ESPAT::readStrUntil(string * str, char until) {
    while (true) {
        char c = espSerial.getc();
        if (c != until) {
            *str += c;
        } else {
            break;
        }
    }
}

void ESPAT::waitFor(char * text) {
    //string s;
    for (int i = 0; i < strlen(text); i++) {
        char c = espSerial.getc();
        //s += c;
        if (c != text[i]) {
            i = 0;
        }
    }
    //pc.printf("%s", s.c_str());
}

void ESPAT::sendCommand(char * cmd, bool waitOk) {
    //pc.printf("%s\r\n", cmd);
    espSerial.printf("%s\r\n", cmd);
    if (waitOk) waitFor("OK");
}

void ESPAT::resetEsp() {
    sendCommand("AT+RST");
    waitFor("ready");
}

void ESPAT::initWifiStation(string ssid, string pwd) {
    sendCommand("AT+CWMODE_CUR=1");
    string wifiCmd = "AT+CWJAP_CUR=\"" + ssid + "\",\"" + pwd + "\"";
    sendCommand((char*) wifiCmd.c_str());
}

void ESPAT::initWifiAP(string ssid, string pwd, string channel, string encryption) {
    sendCommand("AT+CWMODE_CUR=2");
    string wifiCmd = "AT+CWSAP_CUR=\"" + ssid + "\",\"" + pwd + "\"," + channel + "," + encryption;
    sendCommand((char*) wifiCmd.c_str());
}

void ESPAT::initServer(void (*requestHandler)(int, string)) {
    sendCommand("AT+CIPMUX=1");
    sendCommand("AT+CIPSERVER=1,80");
    while (true) {
        // Input looks like this: +IPD,0,372:GET / HTTP/1.1
        waitFor("+IPD,");
        // Parse linkId
        int linkId = 0;
        char c;
        while (true) {
            c = espSerial.getc();
            if (c == ',') break;
            linkId = linkId * 10 + (c - '0');
        }
        // Parse path
        waitFor(":GET ");
        string path;
        readStrUntil(&path, ' ');
        // Send request to handler
        requestHandler(linkId, path);
    }
}

void ESPAT::tcpReply(int linkId, string data) {
    espSerial.printf("AT+CIPSEND=%d,%d\r\n", linkId, data.length());
    wait(0.1); // Can't use waitFor here as it isn't fast enough
    for (int i = 0; i < data.length(); i++) {
        // Artificially slowing down this to prevent errors
        espSerial.printf("%c", data[i]);
    }
    waitFor("SEND OK");
    espSerial.printf("AT+CIPCLOSE=%d\r\n", linkId);
    waitFor("OK");
}

void ESPAT::httpReply(int linkId, string code, string payload) {
    string data = "HTTP/1.1 " + code + "\r\nContent-Type: text/html\r\n\r\n" + payload;
    tcpReply(linkId, data);
}
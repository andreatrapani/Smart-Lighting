#ifndef ESPAT_H
#define ESPAT_H

#include "mbed.h"
#include "string"

/*
Library for using an ESP8266 (e.g. ESP-01 board) with its AT command firmware as webserver
Version: 1.0.0
(C)2019 Elias Nestl
*/

class ESPAT {
public:
    ESPAT(PinName tx, PinName rx, int baud = 115200);
    void resetEsp();
    void initWifiStation(string ssid, string pwd);
    void initWifiAP(string ssid = "ESPAT", string pwd = "12345678", string channel = "5", string encryption = "3");
    void initServer(void (*requestHandler)(int, string));
    void tcpReply(int linkId, string data);
    void httpReply(int linkId, string code, string payload);
private:
    Serial espSerial;
    string wifiName;
    string wifiPass;
    void readStrUntil(string * str, char until);
    void waitFor(char * text);
    void sendCommand(char * cmd, bool waitOk = true);
};

#endif